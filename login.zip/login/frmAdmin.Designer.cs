﻿namespace login
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdmin));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkButton5 = new DevExpress.XtraEditors.CheckButton();
            this.label1 = new System.Windows.Forms.Label();
            this.checkButton4 = new DevExpress.XtraEditors.CheckButton();
            this.checkButton1 = new DevExpress.XtraEditors.CheckButton();
            this.checkButton3 = new DevExpress.XtraEditors.CheckButton();
            this.checkButton2 = new DevExpress.XtraEditors.CheckButton();
            this.frmAdminlayoutControl1ConvertedLayout = new DevExpress.XtraLayout.LayoutControl();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.panel1item = new DevExpress.XtraLayout.LayoutControlItem();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.frmAdminlayoutControl1ConvertedLayout)).BeginInit();
            this.frmAdminlayoutControl1ConvertedLayout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panel1item)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1358, 914);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.checkButton5);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.checkButton4);
            this.panel2.Controls.Add(this.checkButton1);
            this.panel2.Controls.Add(this.checkButton3);
            this.panel2.Controls.Add(this.checkButton2);
            this.panel2.Location = new System.Drawing.Point(16, 14);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(256, 1100);
            this.panel2.TabIndex = 7;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(28, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(188, 161);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // checkButton5
            // 
            this.checkButton5.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkButton5.Appearance.ForeColor = System.Drawing.Color.Red;
            this.checkButton5.Appearance.Options.UseFont = true;
            this.checkButton5.Appearance.Options.UseForeColor = true;
            this.checkButton5.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("checkButton5.ImageOptions.SvgImage")));
            this.checkButton5.Location = new System.Drawing.Point(0, 726);
            this.checkButton5.Name = "checkButton5";
            this.checkButton5.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.checkButton5.Size = new System.Drawing.Size(253, 45);
            this.checkButton5.TabIndex = 6;
            this.checkButton5.Text = "Đăng Xuất ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(64, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "Admin";
            // 
            // checkButton4
            // 
            this.checkButton4.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkButton4.Appearance.ForeColor = System.Drawing.Color.Red;
            this.checkButton4.Appearance.Options.UseFont = true;
            this.checkButton4.Appearance.Options.UseForeColor = true;
            this.checkButton4.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("checkButton4.ImageOptions.SvgImage")));
            this.checkButton4.Location = new System.Drawing.Point(0, 626);
            this.checkButton4.Name = "checkButton4";
            this.checkButton4.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.checkButton4.Size = new System.Drawing.Size(256, 45);
            this.checkButton4.TabIndex = 5;
            this.checkButton4.Text = "Hồ Sơ";
            // 
            // checkButton1
            // 
            this.checkButton1.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkButton1.Appearance.ForeColor = System.Drawing.Color.Red;
            this.checkButton1.Appearance.Options.UseFont = true;
            this.checkButton1.Appearance.Options.UseForeColor = true;
            this.checkButton1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("checkButton1.ImageOptions.SvgImage")));
            this.checkButton1.Location = new System.Drawing.Point(3, 313);
            this.checkButton1.Name = "checkButton1";
            this.checkButton1.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.checkButton1.Size = new System.Drawing.Size(250, 45);
            this.checkButton1.TabIndex = 2;
            this.checkButton1.Text = "Bảng Điều Khiển ";
            // 
            // checkButton3
            // 
            this.checkButton3.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkButton3.Appearance.ForeColor = System.Drawing.Color.Red;
            this.checkButton3.Appearance.Options.UseFont = true;
            this.checkButton3.Appearance.Options.UseForeColor = true;
            this.checkButton3.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("checkButton3.ImageOptions.SvgImage")));
            this.checkButton3.Location = new System.Drawing.Point(0, 531);
            this.checkButton3.Name = "checkButton3";
            this.checkButton3.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.checkButton3.Size = new System.Drawing.Size(256, 45);
            this.checkButton3.TabIndex = 4;
            this.checkButton3.Text = "Xem Người Dùng ";
            // 
            // checkButton2
            // 
            this.checkButton2.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkButton2.Appearance.ForeColor = System.Drawing.Color.Red;
            this.checkButton2.Appearance.Options.UseFont = true;
            this.checkButton2.Appearance.Options.UseForeColor = true;
            this.checkButton2.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("checkButton2.ImageOptions.SvgImage")));
            this.checkButton2.Location = new System.Drawing.Point(0, 420);
            this.checkButton2.Name = "checkButton2";
            this.checkButton2.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.checkButton2.Size = new System.Drawing.Size(256, 45);
            this.checkButton2.TabIndex = 3;
            this.checkButton2.Text = "Thêm Người Dùng";
            // 
            // frmAdminlayoutControl1ConvertedLayout
            // 
            this.frmAdminlayoutControl1ConvertedLayout.Controls.Add(this.panel1);
            this.frmAdminlayoutControl1ConvertedLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.frmAdminlayoutControl1ConvertedLayout.Location = new System.Drawing.Point(0, 0);
            this.frmAdminlayoutControl1ConvertedLayout.Name = "frmAdminlayoutControl1ConvertedLayout";
            this.frmAdminlayoutControl1ConvertedLayout.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(1108, 44, 812, 500);
            this.frmAdminlayoutControl1ConvertedLayout.Root = this.layoutControlGroup1;
            this.frmAdminlayoutControl1ConvertedLayout.Size = new System.Drawing.Size(1382, 938);
            this.frmAdminlayoutControl1ConvertedLayout.TabIndex = 1;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.panel1item});
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1382, 938);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // panel1item
            // 
            this.panel1item.Control = this.panel1;
            this.panel1item.Location = new System.Drawing.Point(0, 0);
            this.panel1item.Name = "panel1item";
            this.panel1item.Size = new System.Drawing.Size(1362, 918);
            this.panel1item.TextSize = new System.Drawing.Size(0, 0);
            this.panel1item.TextVisible = false;
            // 
            // frmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1382, 938);
            this.Controls.Add(this.frmAdminlayoutControl1ConvertedLayout);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAdmin";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.frmAdminlayoutControl1ConvertedLayout)).EndInit();
            this.frmAdminlayoutControl1ConvertedLayout.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panel1item)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private DevExpress.XtraEditors.CheckButton checkButton1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.CheckButton checkButton5;
        private DevExpress.XtraEditors.CheckButton checkButton4;
        private DevExpress.XtraEditors.CheckButton checkButton3;
        private DevExpress.XtraEditors.CheckButton checkButton2;
        private DevExpress.XtraLayout.LayoutControl frmAdminlayoutControl1ConvertedLayout;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem panel1item;
        private System.Windows.Forms.Panel panel2;
    }
}